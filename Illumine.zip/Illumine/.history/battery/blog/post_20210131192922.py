from battery.blog.db import Post

class Main:
    def __init__(self, env,path):
        self.env=env
        self.path=path
        self.name ="post"

    def main(self,request=None,arg=None,plugin=None):
        if request != None:
            return render_template("post.html", posts = Post.select().where(Post.title == arg))