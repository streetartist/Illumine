from battery.blog.archive import Main as Archive

dispose = [
    Archive,
    Post
    ]