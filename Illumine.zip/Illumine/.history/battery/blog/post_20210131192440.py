@app.route("/post/<title>",methods= ["POST","GET"])
def post(title):
    if request.method == "GET":
        return render_template("post.html", posts = Post_.select().where(Post_.title == title))